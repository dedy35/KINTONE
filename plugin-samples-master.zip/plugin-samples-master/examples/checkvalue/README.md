# Input Value Check Plug-in

## OSS License

* kintone-config-helper - https://github.com/kintone-labs/config-helper
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-labs/config-helper/blob/master/LICENSE)
* jQuery - https://jquery.com/
  * Author:  jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/1.11.1/MIT-LICENSE.txt)
* JsRender - https://www.jsviews.com/
  * Author: Boris Moore
  * License: [MIT License](https://github.com/BorisMoore/jsrender/blob/v1.0.6/MIT-LICENSE.txt)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
