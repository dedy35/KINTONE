# Conditional Format Plug-in

## OSS License

* Luxon - https://moment.github.io/luxon/
  * Author: JS Foundation and other contributors
  * Lisense: [MIT License](https://github.com/moment/luxon/blob/3.4.4/LICENSE.md)
* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/2.1.4/MIT-LICENSE.txt)
* JsRender - https://www.jsviews.com/
  * Author: Boris Moore
  * License: [MIT License](https://github.com/BorisMoore/jsrender/blob/v0.9.83/MIT-LICENSE.txt)
* tinyColorPicker and colors - https://github.com/PitPik/tinyColorPicker
  * Author: Peter Dematté
  * License: [MIT License](https://github.com/PitPik/tinyColorPicker/blob/1.1.1/LICENSE.md)
* color-paint-brush in config.html  
  @fontawesome - https://fontawesome.com
  * Author: Dave Gandy
  * Lisense: [CC BY 4.0 License](https://github.com/FortAwesome/Font-Awesome/blob/v4.7.0/README.md#license)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
