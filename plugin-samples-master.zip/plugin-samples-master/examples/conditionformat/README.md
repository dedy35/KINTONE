# Conditional Format Plug-in

## OSS License

* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/1.11.1/MIT-LICENSE.txt)
* cpick.js
  * Author: futomi
  * License: [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0)
