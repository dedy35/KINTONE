# kintone Event Calendar Plug-in

## OSS License

* Moment.js - https://momentjs.com/
  * Author: Tim Wood, Iskren Chernev, Moment.js contributors
  * License: [MIT License](https://github.com/moment/moment/blob/2.13.0/LICENSE)
* FullCalendar - https://fullcalendar.io/
  * Author: Adam Shaw
  * License: [MIT License](https://github.com/fullcalendar/fullcalendar/blob/v2.7.3/LICENSE.txt)
* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/2.2.4/LICENSE.txt)
* JsRender - https://www.jsviews.com/
  * Author: Boris Moore
  * License: [MIT License](https://github.com/BorisMoore/jsrender/blob/v1.0.5/MIT-LICENSE.txt)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
