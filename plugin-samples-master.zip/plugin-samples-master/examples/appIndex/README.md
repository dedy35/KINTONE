# App index Plug-in

## OSS License

* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/1.11.1/MIT-LICENSE.txt)
* JSTree - http://www.jstree.com/
  * Author: Ivan Bozhanov
  * License: [MIT License](https://github.com/vakata/jstree/blob/3.3.1/LICENSE-MIT)
* SweetAlert - https://t4t5.github.io/sweetalert/
  * Author: Tristan Edwards
  * License: [MIT License](https://github.com/t4t5/sweetalert/blob/v1.1.3/LICENSE)
* Bootstrap - https://getbootstrap.com/
  * Author: Twitter, Inc.
  * License: [MIT License](https://github.com/twbs/bootstrap/blob/v3.3.7/LICENSE)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
