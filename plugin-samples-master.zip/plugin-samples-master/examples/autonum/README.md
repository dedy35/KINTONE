# Auto-numbering Plug-in

## OSS License

* Moment.js - https://momentjs.com/
  * Author: Tim Wood, Iskren Chernev, Moment.js contributors
  * License: [MIT License](https://github.com/moment/moment/blob/2.14.1/LICENSE)
* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/2.1.3/MIT-LICENSE.txt)
* JsRender - https://www.jsviews.com/
  * Author: Boris Moore
  * License: [MIT License](https://github.com/BorisMoore/jsrender/blob/v0.9.80/MIT-LICENSE.txt)
* SweetAlert - https://t4t5.github.io/sweetalert/
  * Author: Tristan Edwards
  * License: [MIT License](https://github.com/t4t5/sweetalert/blob/v1.1.3/LICENSE)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
