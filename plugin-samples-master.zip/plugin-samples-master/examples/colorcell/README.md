# Color Cell Plug-in

## OSS License

* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/2.1.1/MIT-LICENSE.txt)
