# Map Plug-in

## OSS License

* jQuery - https://jquery.com/  
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/2.1.3/MIT-LICENSE.txt)
