# GanttChart Plug-in

## OSS License

* jQuery UI - https://jqueryui.com/
  * Author: jQuery Foundation and other contributors
  * License: [See License](https://github.com/jquery/jquery-ui/blob/1.12.1/LICENSE.txt)
* jQuery.Gantt - http://taitems.github.io/jQuery.Gantt/
  * Author: Marek Bielańczuk, Tait Brown, Leo Pfeifenberger, Grzegorz Russek and Contributors
  * License: [MIT License](https://github.com/taitems/jQuery.Gantt/blob/master/LICENSE)
* Moment.js - https://momentjs.com/
  * Author: Tim Wood, Iskren Chernev, Moment.js contributors
  * License: [MIT License](https://github.com/moment/moment/blob/2.14.1/LICENSE)
* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/2.1.3/MIT-LICENSE.txt)
* JsRender - https://www.jsviews.com/
  * Author: Boris Moore
  * License: [MIT License](https://github.com/BorisMoore/jsrender/blob/v0.9.80/MIT-LICENSE.txt)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
