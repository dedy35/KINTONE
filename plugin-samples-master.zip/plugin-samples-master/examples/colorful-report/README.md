# Colorful Weekly Report Plug-in

## OSS License

* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/1.12.3/LICENSE.txt)
* JsRender - https://www.jsviews.com/
  * Author: Boris Moore
  * License: [MIT License](https://github.com/BorisMoore/jsrender/blob/v1.0.5/MIT-LICENSE.txt)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
