# Like Plug-in

## OSS License

* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/1.11.1/MIT-LICENSE.txt)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
