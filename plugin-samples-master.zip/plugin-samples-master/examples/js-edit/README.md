# JSEdit for kintone Plug-in

## OSS License

* Ace - http://ace.c9.io/
  * Author: Fabian Jakobs
  * License: [The 3-Clause BSD License](https://github.com/ajaxorg/ace/blob/v1.4.1/LICENSE)
* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/2.1.3/MIT-LICENSE.txt)
* kintone UI Component - https://kintone-labs.github.io/kintone-ui-component/  
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-labs/kintone-ui-component/blob/v0.4.2/LICENSE)
