# Text Connect Plug-in

## OSS License

* jQuery - https://jquery.com/
  * Author: jQuery Foundation, Inc.
  * License: [MIT License](https://github.com/jquery/jquery/blob/3.3.1/LICENSE.txt)
* JsRender - https://www.jsviews.com/
  * Author: Boris Moore
  * License: [MIT License](https://github.com/BorisMoore/jsrender/blob/v0.9.86/MIT-LICENSE.txt)
* SweetAlert - https://t4t5.github.io/sweetalert/
  * Author: Tristan Edwards
  * License: [MIT License](https://github.com/t4t5/sweetalert/blob/v1.1.3/LICENSE)
* 51-modern-default - https://cybozu.dev/ja/kintone/sdk/library/plugin-stylesheet-guide/
  * Author: Cybozu, Inc.
  * License: [MIT License](https://github.com/kintone-samples/plugin-samples#licence)
